package com.tutorial.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThymeleafSpringbootTutorialApplicationTests {

	@Test
	void contextLoads() {
	}

}
