function demo(){
	alert("Thymeleaf with CSS and JS demo");
}